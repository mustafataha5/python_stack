$(document).ready(function () {

    $(".collapse-a").click(function () {
        $(this).text = old == "Show" ? "Hide" : "Show";
    });

});
