from django.apps import AppConfig


class FilmActorAppConfig(AppConfig):
    name = 'film_actor_app'
